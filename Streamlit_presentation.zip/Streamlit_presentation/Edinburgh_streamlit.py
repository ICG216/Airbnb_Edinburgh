import streamlit as st
import pandas as pd
import plotly.express as px

# -- Custom CSS for Styling -- 
custom_css = """
<style>
/* Title text styling (centered, red text, increased font size) */
h1.title {
    color: #ff385c;
    font-size: 4rem; /* Increased font size */
    font-weight: bold;
    margin-bottom: 1rem;
    margin-top: 0;
    text-align: center; /* Center the title */
}

/* White background for the app */
[data-testid="stAppViewContainer"] {
    background-color: white;
    padding-top: 0; /* Remove extra padding */
    padding-left: 0; /* Remove left padding */
    padding-right: 0; /* Remove right padding */
    margin-left: 0; /* Remove left margin */
    margin-right: 0; /* Remove right margin */
    width: 100%; /* Allow full width */
}

/* Sidebar styling */
[data-testid="stSidebar"] {
    background-color: #ff385c;
    color: white;
    padding-top: 0; /* Remove padding at the top */
}

/* Sidebar text styling */
[data-testid="stSidebar"] .css-1d391kg p,
[data-testid="stSidebar"] .css-1d391kg label,
[data-testid="stSidebar"] .css-1d391kg span {
    color: white !important;
}

/* Subheader styling (red color for subheaders) */
.custom-subheader {
    color: #ff385c;
    font-size: 1.5rem;
    font-weight: bold;
    margin-bottom: 1rem;
    margin-top: 2rem;
}

/* Dark grey text for other content */
[data-testid="stMarkdownContainer"] {
    color: #333333;
}

/* Remove iframe container padding and margin */
iframe {
    display: block; /* Remove inline-block spacing */
    margin: 0 auto; /* Center iframe */
    padding: 0; /* Remove padding */
    border: none; /* Remove border */
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# -- Sidebar Without Logo --
with st.sidebar:
    st.title("Edinburgh Airbnb Analysis")

menu = st.sidebar.radio(
    "Navigate",
    ["Introduction", "Data Insights", "Power BI Dashboard", "Conclusions"]
)

# Function to display the page title with red text, centered
def page_header(title):
    st.markdown(f"<h1 class='title'>{title}</h1>", unsafe_allow_html=True)

# Function for custom subheaders
def custom_subheader(subheader_text):
    st.markdown(f"""
    <p class="custom-subheader">{subheader_text}</p>
    """, unsafe_allow_html=True)

# -- Page 1: Introduction --
if menu == "Introduction":
    page_header("Edinburgh Airbnb Revenue Analysis")
            # Display the uploaded image
    try:
        st.image("Mountain-view-over-city-Edinburgh.png", caption="Edinburgh City View", use_column_width=True)
    except FileNotFoundError:
        st.markdown("⚠️ **Image not found. Please check the file name and location.**")
    st.markdown("""
    Welcome to the Edinburgh Airbnb data analysis presentation. 
    As a **Revenue Manager**, my objective is to maximize revenue through:
    - Optimizing pricing strategies.
    - Increasing occupancy rates.
    - Leveraging data insights for informed decisions.

    This presentation will guide you through our findings and recommended strategies.
    """)



# -- Page 2: Data Insights --
if menu == "Data Insights":
    page_header("Data Insights and Visualizations")
    
    custom_subheader("Occupancy Trends Over Time")
    # Display the uploaded image
    try:
        st.image("Availability-over-time.png", use_column_width=True)
    except FileNotFoundError:
        st.markdown("⚠️ **Image not found. Please check the file name and location.**")
    
    st.markdown(""" 
    **Seasonality:**

    - The rise in availability during Autumn/Winter aligns with the lower tourist season when fewer travelers visit Edinburgh.
    - The decline in Summer aligns with peak travel periods like festivals and holidays.

    **Local Events:**

    - The Edinburgh International Festival (August).
    - Christmas and New Year holidays (December-January).
    - Smaller events or conferences.
    """)
    custom_subheader("Price Distribution")
    # Display the uploaded image
    try:
        st.image("Price-distribution.png", use_column_width=True)
    except FileNotFoundError:
        st.markdown("⚠️ **Image not found. Please check the file name and location.**")
    st.markdown(""" 
    - The data is heavily skewed to the right, with the majority of listings priced below $500.

    - A small number of listings have extreme prices, significantly higher than the majority.
    These outliers may represent luxury properties or misreported prices.

    - There is a sharp peak around $0 to $200, indicating that most listings are budget-friendly.
    """)
    
    custom_subheader("Word Cloud of Reviews")
    # Word cloud placeholder
    st.image("Wordcloud.png", caption="Common Review Keywords")
    st.markdown(""" 
    - **Positive Sentiment:**

        - Words like "great," "clean," "comfortable," "lovely," "perfect," "helpful," and "beautiful" suggest that guests frequently use positive adjectives to describe their experiences. This indicates a high level of guest satisfaction in many cases.

    - **Location Matters:**

        - Words like "Edinburgh," "location," "city centre," "Royal Mile," "walking distance," and "close" emphasize that the location of listings is a critical factor in guest reviews. Proximity to key attractions like the **Royal Mile** and city center is a recurring theme.

    - **Amenities and Features:**

        - Guests mention terms like "clean," "spacious," "comfortable," "kitchen," and "bedroom", which highlight the importance of cleanliness and functional amenities in guest satisfaction.

    - **Host Interaction:**

        - Words like "helpful," "responsive," "kind," and "friendly" indicate that hosts' behavior and communication play a significant role in shaping guests' perceptions.

    - **Recommendations:**

        - Terms like "highly recommend" and "recommend" are prominent, which suggests that many guests are satisfied enough to recommend the listings to others.
    """)

# -- Page 3: Power BI Dashboard --
if menu == "Power BI Dashboard":
    power_bi_url = f'https://app.powerbi.com/view?r=eyJrIjoiY2YwNzdjZmUtZjBhNy00YmZjLTgxZmYtZDgxYjVhYThjYWEzIiwidCI6IjhhZWJkZGI2LTM0MTgtNDNhMS1hMjU1LWI5NjQxODZlY2M2NCIsImMiOjl9'
    st.markdown(f"""
    <iframe title="Edinburgh_BI02" width="100%" height="486" src="{power_bi_url}" frameborder="0" allowFullScreen="true"></iframe>
    """, unsafe_allow_html=True)

# -- Page 4: Conclusions --
if menu == "Conclusions":
    page_header("Conclusions")
    
    st.markdown("""
    Based on my analysis, here are the key takeaways:
    1. **Pricing Strategy:** Adjust prices based on seasonality to maximize revenue.
    2. **High-Performing Neighborhoods:** Focus marketing and resources on Old Town and New Town.
    3. **Customer Sentiment:** Address common concerns from reviews to improve overall satisfaction.
    4. **Forecasting:** Use ARIMA or Prophet models to predict demand for better planning.

    Thank you for your attention!
    """)
    st.image("travel-image.jpg", use_column_width=True)
    custom_subheader("Questions?")
    st.markdown("Feel free to reach out with any questions or clarifications.")
    st.markdown("email: ines.camerlynck@bootcamp-upgrade.com")

